def main():
    cmd = (raw_input('>>>'))
    if cmd=="tst":
        print "tst"
        main()
    else:
        print cmd,
        print "is an unknown command."
        main()
print "Shell"
main()

